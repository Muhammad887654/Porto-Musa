# Portofolio Muhamad Saefuloh

Website portofolio statis (HTML, CSS, JavaScript murni). Tanpa build, tanpa dependensi.

## Struktur
- `index.html`   : kerangka halaman dan ilustrasi SVG (kantor, grafik, diagram)
- `style.css`    : seluruh gaya, termasuk tema terang/gelap
- `script.js`    : data profil (objek `P` di bagian atas) dan interaksi (efek foto dan kursor ada di bagian bawah)
- `assets/banner.jpg`  : gambar latar hero
- `assets/profile.jpg` : foto profil di bagian Tentang
- `assets/office.jpg`  : gambar latar bagian Pengalaman & Pendidikan

## Mengubah isi
Buka `script.js`, edit objek `P` di bagian atas: nama, peran, tagline, tentang, statistik, keahlian, proyek, pengalaman, dan email.
Ganti `emailanda@contoh.com` dengan email Anda.
Untuk mengganti gambar, timpa file di folder `assets` dengan nama yang sama.

## Menjalankan
Buka `index.html` di browser, atau jalankan server lokal: `python3 -m http.server 8000` lalu buka http://localhost:8000

## Publikasi gratis
- GitHub Pages: unggah semua file ke repo, lalu Settings > Pages > pilih branch `main`.
- Netlify atau Vercel: seret folder ini ke dashboard.
